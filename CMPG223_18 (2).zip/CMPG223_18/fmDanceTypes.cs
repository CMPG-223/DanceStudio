﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG223_18
{
    public partial class fmDanceTypes : Form
    {
        string conString = @"Data Source=STARHAPPY_07\SQLEXPRESS;Initial Catalog=DanceStudio1;Integrated Security=True";
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataSet dset;
        SqlDataReader reader;
        public fmDanceTypes()
        {
            InitializeComponent();
        }

        private void fmDanceTypes_Load(object sender, EventArgs e)
        {
           

            grpDanceTypes.Hide();            
            PopulateDanceType();
            ViewDanceTypes();
        }

        

        private void ViewDanceTypes()
        {
            try
            {
                using (conn = new SqlConnection(conString))
                {
                    conn.Open();

                    string cmdString = "SELECT * FROM DANCE_TYPE";
                    cmd = new SqlCommand(cmdString, conn);

                    adpt = new SqlDataAdapter();
                    dset = new DataSet();
                    adpt.SelectCommand = cmd;
                    adpt.Fill(dset, "DANCE_TYPES");

                    dgvDisplayDanceTypes.DataSource = dset;
                    dgvDisplayDanceTypes.DataMember = "DANCE_TYPES";

                    conn.Close();
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void PopulateDanceType()
        {
            try
            {
                using (conn = new SqlConnection(conString))
                {
                    conn.Open();
                    cmbDanceType.Items.Clear();
                    string cmdString = "SELECT DISTINCT Type_Desc FROM DANCE_TYPE";
                    cmd = new SqlCommand(cmdString, conn);

                    reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        cmbDanceType.Items.Add(reader.GetValue(0));
                    }

                    conn.Close();
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMain mainPage = new frmMain();
            mainPage.ShowDialog();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Close();
            frmLogIn startPage = new frmLogIn();
            startPage.ShowDialog();
        }

        private void btnAddDanceType_Click(object sender, EventArgs e)
        {
           try
           {
                if(rdbAdd.Checked)
                {
                    if (cmbDanceType.SelectedIndex == -1)
                    {
                        errCombobox.SetError(cmbDanceType, "Please fill the dance type.");
                        cmbDanceType.SelectedIndex = -1;
                        return;
                    }
                    else
                    {
                        errCombobox.Clear();

                    }

                    if (string.IsNullOrEmpty(txtAddDanceType.Text))
                    {
                        errTextbox.SetError(txtAddDanceType, "Please fill the teacher's first name.");

                        txtAddDanceType.Text = "";


                        return;
                    }
                    else
                    {
                        errTextbox.Clear();

                    }                   

                    var confirm = MessageBox.Show("Are you sure you want to add to the dance types", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (confirm == DialogResult.Yes)
                    {
                        grpDanceTypes.Show();
                        string userDanceType = txtAddDanceType.Text;

                        using (conn = new SqlConnection(conString))
                        {
                            string addQuery = "INSERT INTO DANCE_TYPE(Type_Desc) VALUES (@userDanceType)";
                            cmd = new SqlCommand(addQuery, conn);
                            cmd.Parameters.AddWithValue("@userDanceType", userDanceType);

                            conn.Open();

                            int addedDT = cmd.ExecuteNonQuery();
                            if (addedDT > 0)
                            {
                                MessageBox.Show("Dance type added successfully.", "Success.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                txtAddDanceType.Text = "";
                                ViewDanceTypes();
                                PopulateDanceType();
                            }
                            conn.Close();

                        }
                    }
                }
                
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
            
        }

        private void rdbAdd_CheckedChanged(object sender, EventArgs e)
        {
            
                grpDanceTypes.Visible = true;
        }

        private void rdbUpdate_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbUpdate.Checked)
            {
                grpDanceTypes.Show();
                btnAddDanceType.Hide();
            }
            else
                grpDanceTypes.Hide();
        }

        private void btnComplete_Click(object sender, EventArgs e)
        {
            if(rdbUpdate.Checked)
            {
                if (cmbDanceType.SelectedIndex == -1)
                {
                    errCombobox.SetError(cmbDanceType, "Please fill the dance type.");
                    cmbDanceType.SelectedIndex = -1;
                    return;
                }
                else
                {
                    errCombobox.Clear();

                }

                if (string.IsNullOrEmpty(txtAddDanceType.Text))
                {
                    errTextbox.SetError(txtAddDanceType, "Please fill the teacher's first name.");

                    txtAddDanceType.Text = "";


                    return;
                }
                else
                {
                    errTextbox.Clear();

                }

                var confirm = MessageBox.Show("Are you sure you want to update the dance type?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    string selectedDT = cmbDanceType.SelectedItem.ToString();
                    string updatedText = txtAddDanceType.Text;

                    using (conn = new SqlConnection(conString))
                    {
                        conn.Open();

                        string updateQuery = "UPDATE DANCE_TYPE SET Type_Desc = @updatedText WHERE Type_Desc = @selectedDT";
                        cmd = new SqlCommand(updateQuery, conn);
                        cmd.Parameters.AddWithValue("@updatedText", updatedText);
                        cmd.Parameters.AddWithValue("@selectedDT", selectedDT);


                        int rowsUpdated = cmd.ExecuteNonQuery();
                        if (rowsUpdated > 0)
                        {
                            MessageBox.Show("Dance type updated successfull.y", "Success.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtAddDanceType.Text = "";
                            ViewDanceTypes();
                            PopulateDanceType();
                        }
                        conn.Close();
                    }
                }                
            }
            else if (rdbDelete.Checked)
            {
                if (cmbDanceType.SelectedIndex == -1)
                {
                    errCombobox.SetError(cmbDanceType, "Please fill the dance type.");
                    cmbDanceType.SelectedIndex = -1;
                    return;
                }
                else
                {
                    errCombobox.Clear();

                }

                var confirm = MessageBox.Show("Are you sure you want to delete the dance type?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    string selectedDT = cmbDanceType.SelectedItem.ToString();

                    using (conn = new SqlConnection(conString))
                    {
                        foreach (DataGridViewRow rowID in dgvDisplayDanceTypes.Rows)
                        {
                            if (rowID.Cells["Type_Desc"].Value.ToString() == selectedDT)
                            {
                                conn.Open();
                                int danceID = Convert.ToInt32(rowID.Cells["Dance_Type_ID"].Value);

                                string deleteQuery = "DELETE FROM DANCE_TYPE WHERE Dance_Type_ID = @danceID";
                                cmd = new SqlCommand(deleteQuery, conn);
                                cmd.Parameters.AddWithValue("@danceID", danceID);

                                int rowsDeleted = cmd.ExecuteNonQuery();
                                if (rowsDeleted > 0)
                                {
                                    MessageBox.Show("Dance type deleted successfully.", "Success.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    ViewDanceTypes();
                                    PopulateDanceType();
                                }
                                conn.Close();
                            }
                        }
                    }
                }               
            }
        }

        private void rdbDelete_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbDelete.Checked)
            {
                grpDanceTypes.Show();
                btnAddDanceType.Hide();
                txtAddDanceType.Hide();
                lblAddDanceType.Hide();
            }
            else
                grpDanceTypes.Hide();
        }

        private void dgvDisplayDanceTypes_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string searchCmd = "SELECT * FROM DANCE_TYPE WHERE Type_Desc LIKE '%" + txtSearch.Text + "%'";        //Display info in listbox based on charcters typed for movie name
                Display(searchCmd);
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"An error occurred while loading words: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Display(string searchCmd)
        {
            try
            {
                using (conn = new SqlConnection(conString))
                {
                    conn.Open();

                    
                    cmd = new SqlCommand(searchCmd, conn);

                    adpt = new SqlDataAdapter();
                    dset = new DataSet();
                    adpt.SelectCommand = cmd;
                    adpt.Fill(dset, "DANCE_TYPES");

                    dgvDisplayDanceTypes.DataSource = dset;
                    dgvDisplayDanceTypes.DataMember = "DANCE_TYPES";

                    conn.Close();
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
