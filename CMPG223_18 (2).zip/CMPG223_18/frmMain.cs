﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMPG223_18
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void btnEnrol_Click(object sender, EventArgs e)
        {
            this.Close();
            frmEnrol currentpage = new frmEnrol();
            currentpage.ShowDialog();            
        }

        private void btnExpLvl_Click(object sender, EventArgs e)
        {
            this.Close();
            frmExperienceLevel currentpage = new frmExperienceLevel();
            currentpage.ShowDialog();
        }

        private void btnDanceType_Click(object sender, EventArgs e)
        {
            this.Close();
            fmDanceTypes currentpage = new fmDanceTypes();
            currentpage.ShowDialog();
        }
    }
}
