﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG223_18
{
    public partial class frmEnrol : Form
    {
        string conString = @"Data Source=STARHAPPY_07\SQLEXPRESS;Initial Catalog=DanceStudio1;Integrated Security=True";
        SqlConnection conn;
        SqlCommand cmd;
        //SqlCommand insertCmd;
        SqlDataAdapter adpt;
        DataSet dset;
        SqlDataReader reader;

        public frmEnrol()
        {
            InitializeComponent();
        }

        private void frmEnrol_Load(object sender, EventArgs e)
        {
            ViewAllDancer();
        }        

        public void ViewAllDancer()
        {
            //needs to include dancer_ID, dancer_FName, dancer_LName,  
            //classID, dancerID,  name surname, enrolment status
            try
            {
                using (conn = new SqlConnection(conString))
                {
                    string displayAll = "SELECT * FROM DANCER";
                    cmd = new SqlCommand(displayAll, conn);

                    conn.Open();
                    adpt = new SqlDataAdapter();
                    dset = new DataSet();
                    adpt.SelectCommand = cmd;
                    adpt.Fill(dset, "DANCER");

                    dgvAllDisplay.DataSource = dset;
                    dgvAllDisplay.DataMember = "DANCER";
                    conn.Close();
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void ViewEnrolment_Status()
        {
            try
            {
                using (conn = new SqlConnection(conString))
                {
                    string displayAll = "SELECT * FROM ENROLLMENT_CLASS";
                    cmd = new SqlCommand(displayAll, conn);

                    conn.Open();
                    adpt = new SqlDataAdapter();
                    dset = new DataSet();
                    adpt.SelectCommand = cmd;
                    adpt.Fill(dset, "ENROLLMENT_CLASS");

                    dgvAllDisplay.DataSource = dset;
                    dgvAllDisplay.DataMember = "ENROLLMENT_CLASS";
                    conn.Close();
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        public void PopulateEnrolledClasses()//for enrolled classes to be efficient, it needs to include dancer info with corresponding class info
        {

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Close();
            frmLogIn startPage = new frmLogIn();
            startPage.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMain mainPage = new frmMain();
            mainPage.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Textboxes act as search function which reads/displays the data from Dancers_Table then when a record is clicked,
            //the record is added to enrolment_TAble the after the button "enrol" is clicked
            //the new & updated enrolment_Table is showed with all its data
            //INCLUDING the dancer name and surname (with the class description)

            try
            {
                if (rdbAdd.Checked)
                {                    
                    ViewEnrolment_Status();                    
                }
                else if(rdbUpdate.Checked)
                {
                    MessageBox.Show("Incorrect selection made under Maintain Enrollment.");
                }
                else if(rdbRemove.Checked)
                {
                    MessageBox.Show("Incorrect selection made under Maintain Enrollment.");
                }
                else
                {
                    MessageBox.Show("Please make a selection under Maintain Enrollment.");

                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (rdbUpdate.Checked)
            {
                ViewEnrolment_Status();
            }
            else if (rdbAdd.Checked)
            {
                MessageBox.Show("Incorrect selection made under Maintain Enrollment.");
            }
            else if (rdbRemove.Checked)
            {
                MessageBox.Show("Incorrect selection made under Maintain Enrollment.");
            }
            else
            {
                MessageBox.Show("Please make a selection under Maintain Enrollment.");

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (rdbRemove.Checked)
            {
                ViewEnrolment_Status();
            }
            else if (rdbAdd.Checked)
            {
                MessageBox.Show("Incorrect selection made under Maintain Enrollment.");
            }
            else if (rdbUpdate.Checked)
            {
                MessageBox.Show("Incorrect selection made under Maintain Enrollment.");
            }
            else
            {
                MessageBox.Show("Please make a selection under Maintain Enrollment.");

            }
        }

        private void dgvAllDisplay_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(rdbAdd.Checked)
                {
                    //checking that a cell is selected
                    if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                    {
                        //getting thee row selected
                        DataGridViewRow row = dgvAllDisplay.Rows[e.RowIndex];

                        //getting the dancer id from the selected row
                        int dancerID = Convert.ToInt32(row.Cells["Dancer_ID"].Value);

                        //updating the enrollment_class table to set the dancer stuff to true
                        using (conn = new SqlConnection(conString))
                        {
                            conn.Open();
                            string updateTable = "UPDATE ENROLLMENT_CLASS SET Enrollment_Status = 1 WHERE Dancer_ID = @dancerID";

                            cmd = new SqlCommand(updateTable, conn);
                            cmd.Parameters.AddWithValue("@dancerID", dancerID);

                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Enrollment status updated successfully!");
                            }
                            else
                            {
                                MessageBox.Show("Error updating enrollment status");
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please make the correct selection under Maintain Enrollment.");
                }       
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {            
            try
            {
                string searchName_Dancer = txtName.Text;
                string searchQuery = "SELECT * FROM DANCER WHERE Dancer_FName LIKE '%" + searchName_Dancer + "%'";

                using (conn = new SqlConnection(conString))
                {
                    conn.Open();

                    adpt = new SqlDataAdapter(searchQuery, conn);
                    DataTable tableSearch = new DataTable();
                    adpt.Fill(tableSearch);
                    dgvAllDisplay.DataSource = tableSearch;

                    conn.Close();
                }
                
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ViewAllDancer();
            rdbAdd.Checked = false;
            rdbRemove.Checked = false;
            rdbUpdate.Checked = false;
        }

        private void rdbUpdate_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbUpdate.Checked)
            {
                ViewEnrolment_Status();
                MessageBox.Show("Enrolment status updated successfully.");
            }
            else if (rdbAdd.Checked)
            {
                MessageBox.Show("Incorrect selection made under Maintain Enrollment.");
            }
            else if (rdbRemove.Checked)
            {
                MessageBox.Show("Incorrect selection made under Maintain Enrollment.");
            }
            else
            {
                MessageBox.Show("Please make a selection under Maintain Enrollment.");

            }
        }

        private void rdbRemove_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbRemove.Checked)
            {
                ViewEnrolment_Status();
            }
            else if (rdbAdd.Checked)
            {
                MessageBox.Show("Incorrect selection made under Maintain Enrollment.");
            }
            else if (rdbUpdate.Checked)
            {
                MessageBox.Show("Incorrect selection made under Maintain Enrollment.");
            }
            else
            {
                MessageBox.Show("Please make a selection under Maintain Enrollment.");

            }
        }

        private void dgvAllDisplay_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            /*UPDATING THE ENROLMENT STATUS*/

            try
            {
                if (rdbUpdate.Checked)
                {
                    // Check if the changed cell is the checkbox column
                    if (e.ColumnIndex == dgvAllDisplay.Columns["Enrollment_Status"].Index)
                    {
                        // Get the new value of the checkbox
                        bool enrollmentStatus = (bool)dgvAllDisplay.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;

                        // Get the customer ID from the same row
                        int customerID = Convert.ToInt32(dgvAllDisplay.Rows[e.RowIndex].Cells["Dancer_ID"].Value);

                        // Update the enrollment status in Table2
                        using (SqlConnection connection = new SqlConnection(conString))
                        {
                            connection.Open();

                            string query = "UPDATE ENROLLMENT_CLASS SET Enrollment_Status = @EnrollmentStatus WHERE Dancer_ID = @dancerID";

                            using (SqlCommand command = new SqlCommand(query, connection))
                            {
                                command.Parameters.AddWithValue("@EnrollmentStatus", enrollmentStatus ? 1 : 0);
                                command.Parameters.AddWithValue("@dancerID", customerID);

                                int rowsAffected = command.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    // No need to show a message here, as the user has already seen the change in the DataGridView
                                }
                                else
                                {
                                    MessageBox.Show("Error updating enrollment status.");
                                }
                            }
                        }
                    }
                }
                else if(rdbRemove.Checked)
                {
                    // Check if the changed cell is the checkbox column
                    if (e.ColumnIndex == dgvAllDisplay.Columns["Enrollment_Status"].Index)
                    {
                        // Get the new value of the checkbox
                        bool enrollmentStatus = (bool)dgvAllDisplay.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;

                        // Get the dancer ID from the same row
                        int dancerID = Convert.ToInt32(dgvAllDisplay.Rows[e.RowIndex].Cells["Dancer_ID"].Value);

                        if (!enrollmentStatus) // If the checkbox is unchecked
                        {
                            // Check if the record was previously checked
                            bool wasPreviouslyChecked = (bool)dgvAllDisplay.Rows[e.RowIndex].Cells[e.ColumnIndex].Tag;

                            if(wasPreviouslyChecked)
                            {
                                // Delete the corresponding record from the table
                                using (conn = new SqlConnection(conString))
                                {
                                    conn.Open();

                                    string deleteQuery = "DELETE FROM ENROLLMENT_CLASS WHERE Dancer_ID = @dancerID";
                                    cmd = new SqlCommand(deleteQuery, conn);
                                    cmd.Parameters.AddWithValue("@dancerID", dancerID);

                                    int rowsDeleted = cmd.ExecuteNonQuery();
                                    if (rowsDeleted > 0)
                                    {
                                        // Remove the row from the DataGridView
                                        dgvAllDisplay.Rows.RemoveAt(e.RowIndex);
                                    }
                                    else
                                    {
                                        MessageBox.Show("Error deleting record.");
                                    }                                   

                                    conn.Close();
                                }
                            }
                            else
                            {
                                // Set the Tag property to false, so we don't delete the record next time
                                dgvAllDisplay.Rows[e.RowIndex].Cells[e.ColumnIndex].Tag = false;
                            }
                        }
                        /**else // If the checkbox is checked
                        {
                            // Update the enrollment status in Table2
                            using (conn = new SqlConnection(conString))
                            {
                                conn.Open();

                                string updateQuery = "UPDATE ENROLLMENT_CLASS SET Enrollment_Status = @EnrollmentStatus WHERE Dancer_ID = @dancerID";
                                cmd = new SqlCommand(updateQuery, conn);                               
                                cmd.Parameters.AddWithValue("@EnrollmentStatus", 1);
                                cmd.Parameters.AddWithValue("@dancerID", dancerID);

                                int rowsAffected = cmd.ExecuteNonQuery();
                                if (rowsAffected > 0)
                                {
                                    // Set the Tag property to true, so we can delete the record next time
                                    dgvAllDisplay.Rows[e.RowIndex].Cells[e.ColumnIndex].Tag = true;
                                }
                                else
                                {
                                    MessageBox.Show("Error updating enrollment status.");
                                }
                                conn.Close();
                            }
                        }*/
                    }
                }
                else
                {
                    MessageBox.Show("Please make the correct selection under Maintain Enrollment.");
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }            
        }
    }
}
