﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG223_18
{
    public partial class frmExperienceLevel : Form
    {
        string conString = @"Data Source=STARHAPPY_07\SQLEXPRESS;Initial Catalog=DanceStudio1;Integrated Security=True";
        SqlConnection conn;
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataSet dset;
        SqlDataReader reader;

        public frmExperienceLevel()
        {
            InitializeComponent();
        }

        private void frmExperienceLevel_Load(object sender, EventArgs e)
        {
            rdbAdd.Checked = false;
            rdbUpdate.Checked = false;
            rdbDelete.Checked = false;

            grpExperienceLvl.Hide();
            //use try catch for everything
            conn = new SqlConnection(conString);
            conn.Open();            
            PopulateExperienceLevel();            
            ViewAllData();
            conn.Close();           
        }

        private void ViewAllData()
        {
            try
            {
                using (conn = new SqlConnection(conString))
                {
                    conn.Open();

                    string cmdString = "SELECT * FROM EXPERIENCE_LEVEL";
                    cmd = new SqlCommand(cmdString, conn);

                    adpt = new SqlDataAdapter();
                    dset = new DataSet();
                    adpt.SelectCommand = cmd;
                    adpt.Fill(dset, "EXPERIENCE_LEVEL");

                    dgvExpLvl.DataSource = dset;
                    dgvExpLvl.DataMember = "EXPERIENCE_LEVEL";

                    conn.Close();
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void PopulateExperienceLevel()
        {
            try
            {
                using (conn = new SqlConnection(conString))
                {
                    conn.Open();
                    cmbExpLvl.Items.Clear();

                    string cmdString = "SELECT DISTINCT exp_Desc FROM EXPERIENCE_LEVEL";
                    cmd = new SqlCommand(cmdString, conn);

                    reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        cmbExpLvl.Items.Add(reader.GetValue(0));
                    }
                    conn.Close();
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }           
        }


        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Close();
            frmLogIn startPage = new frmLogIn();
            startPage.ShowDialog();            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMain mainPage = new frmMain();
            mainPage.ShowDialog();
        }

        private void btnComplete_Click(object sender, EventArgs e)
        {
            if (rdbUpdate.Checked)
            {
                if (cmbExpLvl.SelectedIndex == -1)
                {
                    errCombobox.SetError(cmbExpLvl, "Please fill the dance type.");
                    cmbExpLvl.SelectedIndex = -1;
                    return;
                }
                else
                {
                    errCombobox.Clear();

                }

                if (string.IsNullOrEmpty(txtAddExpLvl.Text))
                {
                    errTextbox.SetError(txtAddExpLvl, "Please fill the teacher's first name.");

                    txtAddExpLvl.Text = "";


                    return;
                }
                else
                {
                    errTextbox.Clear();

                }


                var confirm = MessageBox.Show("Are you sure you want to update the experience level?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    string selectedDT = cmbExpLvl.SelectedItem.ToString();
                    string updatedText = txtAddExpLvl.Text;

                    using (conn = new SqlConnection(conString))
                    {
                        conn.Open();

                        string updateQuery = "UPDATE EXPERIENCE_LEVEL SET exp_Desc = @updatedText WHERE exp_Desc = @selectedDT";
                        cmd = new SqlCommand(updateQuery, conn);
                        cmd.Parameters.AddWithValue("@updatedText", updatedText);
                        cmd.Parameters.AddWithValue("@selectedDT", selectedDT);


                        int rowsUpdated = cmd.ExecuteNonQuery();
                        if (rowsUpdated > 0)
                        {
                            MessageBox.Show("Record updated successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtAddExpLvl.Text = "";
                            PopulateExperienceLevel();
                            ViewAllData();
                        }
                        conn.Close();
                    }                    
                }
            }
            else if (rdbDelete.Checked)
            {
                if (cmbExpLvl.SelectedIndex == -1)
                {
                    errCombobox.SetError(cmbExpLvl, "Please fill the dance type.");
                    cmbExpLvl.SelectedIndex = -1;
                    return;
                }
                else
                {
                    errCombobox.Clear();

                }

                var confirm = MessageBox.Show("Are you sure you want to delete the experience level", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(confirm == DialogResult.Yes)
                {                    
                    try
                    {
                        string deleteExpLvl = cmbExpLvl.SelectedItem.ToString();
                        using (conn = new SqlConnection(conString))
                        {
                            foreach (DataGridViewRow rowID in dgvExpLvl.Rows)
                            {
                                
                                if (rowID.Cells["exp_Desc"].Value.ToString() == deleteExpLvl)
                                {
                                    conn.Open();
                                    int expID = Convert.ToInt32(rowID.Cells["exp_ID"].Value);

                                    string cmdDelete = @"DELETE FROM EXPERIENCE_LEVEL WHERE exp_ID = @expID";
                                    cmd = new SqlCommand(cmdDelete, conn);
                                    cmd.Parameters.AddWithValue("@expID", expID);

                                    int rowsDeleted = cmd.ExecuteNonQuery();
                                    if (rowsDeleted > 0)
                                    {
                                        MessageBox.Show("Record deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        PopulateExperienceLevel();
                                        ViewAllData();
                                    }
                                }
                            }

                            conn.Close();
                        }
                                                        
                    }
                    catch(SqlException error)
                    {
                        MessageBox.Show(error.Message);
                    }                    
                }
            }
            else
                MessageBox.Show("Please select radio button.");
        }

        private void btnAddExpLvl_Click(object sender, EventArgs e)
        {          
            try
            {
                if (rdbAdd.Checked)
                {
                    if (cmbExpLvl.SelectedIndex == -1)
                    {
                        errCombobox.SetError(cmbExpLvl, "Please fill the dance type.");
                        cmbExpLvl.SelectedIndex = -1;
                        return;
                    }
                    else
                    {
                        errCombobox.Clear();

                    }

                    if (string.IsNullOrEmpty(txtAddExpLvl.Text))
                    {
                        errTextbox.SetError(txtAddExpLvl, "Please fill the teacher's first name.");

                        txtAddExpLvl.Text = "";


                        return;
                    }
                    else
                    {
                        errTextbox.Clear();

                    }

                    
                    var confirm = MessageBox.Show("Are you sure you want to add to the experience level?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (confirm == DialogResult.Yes)
                    {
                        grpExperienceLvl.Show();
                        string newExpLvl = txtAddExpLvl.Text;

                        using (conn = new SqlConnection(conString))
                        {
                            string addQuery = "INSERT INTO EXPERIENCE_LEVEL(exp_Desc) VALUES (@newExpLvl)";
                            cmd = new SqlCommand(addQuery, conn);
                            cmd.Parameters.AddWithValue("@newExpLvl", newExpLvl);

                            conn.Open();

                            int addedDT = cmd.ExecuteNonQuery();
                            if (addedDT > 0)
                            {
                                MessageBox.Show("Experience level added successfully.", "Success.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                txtAddExpLvl.Text = "";
                                PopulateExperienceLevel();
                                ViewAllData();
                            }
                            conn.Close();

                        }
                    }                                        
                }                                                      
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }    
        }
                
        private void rdbAdd_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbAdd.Checked)
            {
                grpExperienceLvl.Show();
                lblExpLvl.Visible = true;
                cmbExpLvl.Visible = true;
            }
            else
                grpExperienceLvl.Hide();
        }

        private void rdbUpdate_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbUpdate.Checked)
            {
                grpExperienceLvl.Show();
                lblExpLvl.Visible = true;
                cmbExpLvl.Visible = true;
                btnAddExpLvl.Hide();
            }
            else
                grpExperienceLvl.Hide();
        }

        private void rdbDelete_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbDelete.Checked)
            {
                grpExperienceLvl.Show();
                grpExperienceLvl.Show();
                lblExpLvl.Visible = true;
                cmbExpLvl.Visible = true;
                btnAddExpLvl.Hide();
                txtAddExpLvl.Hide();
                lblAddExpLvl.Hide();
            }
            else
                grpExperienceLvl.Hide();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string searchCmd = "SELECT * FROM EXPERIENCE_LEVEL WHERE exp_Desc LIKE '%" + txtSearch.Text + "%'";        //Display info in listbox based on charcters typed for movie name
                Display(searchCmd);
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"An error occurred while loading words: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Display(string searchCmd)
        {
            try
            {
                using (conn = new SqlConnection(conString))
                {
                    conn.Open();

                    cmd = new SqlCommand(searchCmd, conn);

                    adpt = new SqlDataAdapter();
                    dset = new DataSet();
                    adpt.SelectCommand = cmd;
                    adpt.Fill(dset, "EXPERIENCE_LEVEL");

                    dgvExpLvl.DataSource = dset;
                    dgvExpLvl.DataMember = "EXPERIENCE_LEVEL";

                    conn.Close();
                }
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
