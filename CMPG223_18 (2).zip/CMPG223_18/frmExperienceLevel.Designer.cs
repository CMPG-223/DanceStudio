﻿
namespace CMPG223_18
{
    partial class frmExperienceLevel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmExperienceLevel));
            this.grpExpLvl = new System.Windows.Forms.GroupBox();
            this.rdbDelete = new System.Windows.Forms.RadioButton();
            this.rdbUpdate = new System.Windows.Forms.RadioButton();
            this.rdbAdd = new System.Windows.Forms.RadioButton();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.dgvExpLvl = new System.Windows.Forms.DataGridView();
            this.btnComplete = new System.Windows.Forms.Button();
            this.btnAddExpLvl = new System.Windows.Forms.Button();
            this.grpExperienceLvl = new System.Windows.Forms.GroupBox();
            this.lblAddExpLvl = new System.Windows.Forms.Label();
            this.txtAddExpLvl = new System.Windows.Forms.TextBox();
            this.cmbExpLvl = new System.Windows.Forms.ComboBox();
            this.lblExpLvl = new System.Windows.Forms.Label();
            this.lblSearch = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.errTextbox = new System.Windows.Forms.ErrorProvider(this.components);
            this.errCombobox = new System.Windows.Forms.ErrorProvider(this.components);
            this.grpExpLvl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExpLvl)).BeginInit();
            this.grpExperienceLvl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errTextbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errCombobox)).BeginInit();
            this.SuspendLayout();
            // 
            // grpExpLvl
            // 
            this.grpExpLvl.BackColor = System.Drawing.Color.WhiteSmoke;
            this.grpExpLvl.Controls.Add(this.rdbDelete);
            this.grpExpLvl.Controls.Add(this.rdbUpdate);
            this.grpExpLvl.Controls.Add(this.rdbAdd);
            this.grpExpLvl.Location = new System.Drawing.Point(45, 58);
            this.grpExpLvl.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpExpLvl.Name = "grpExpLvl";
            this.grpExpLvl.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpExpLvl.Size = new System.Drawing.Size(243, 170);
            this.grpExpLvl.TabIndex = 0;
            this.grpExpLvl.TabStop = false;
            this.grpExpLvl.Text = "Select Action";
            // 
            // rdbDelete
            // 
            this.rdbDelete.AutoSize = true;
            this.rdbDelete.Location = new System.Drawing.Point(19, 114);
            this.rdbDelete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbDelete.Name = "rdbDelete";
            this.rdbDelete.Size = new System.Drawing.Size(177, 21);
            this.rdbDelete.TabIndex = 2;
            this.rdbDelete.TabStop = true;
            this.rdbDelete.Text = "Delete Experience level";
            this.rdbDelete.UseVisualStyleBackColor = true;
            this.rdbDelete.CheckedChanged += new System.EventHandler(this.rdbDelete_CheckedChanged);
            // 
            // rdbUpdate
            // 
            this.rdbUpdate.AutoSize = true;
            this.rdbUpdate.Location = new System.Drawing.Point(19, 79);
            this.rdbUpdate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbUpdate.Name = "rdbUpdate";
            this.rdbUpdate.Size = new System.Drawing.Size(182, 21);
            this.rdbUpdate.TabIndex = 1;
            this.rdbUpdate.TabStop = true;
            this.rdbUpdate.Text = "Update Experience level";
            this.rdbUpdate.UseVisualStyleBackColor = true;
            this.rdbUpdate.CheckedChanged += new System.EventHandler(this.rdbUpdate_CheckedChanged);
            // 
            // rdbAdd
            // 
            this.rdbAdd.AutoSize = true;
            this.rdbAdd.Location = new System.Drawing.Point(19, 44);
            this.rdbAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbAdd.Name = "rdbAdd";
            this.rdbAdd.Size = new System.Drawing.Size(161, 21);
            this.rdbAdd.TabIndex = 0;
            this.rdbAdd.TabStop = true;
            this.rdbAdd.Text = "Add Experience level";
            this.rdbAdd.UseVisualStyleBackColor = true;
            this.rdbAdd.CheckedChanged += new System.EventHandler(this.rdbAdd_CheckedChanged);
            // 
            // btnBack
            // 
            this.btnBack.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack.BackgroundImage")));
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBack.Location = new System.Drawing.Point(11, 10);
            this.btnBack.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(32, 29);
            this.btnBack.TabIndex = 4;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.BackColor = System.Drawing.Color.OldLace;
            this.btnLogOut.Font = new System.Drawing.Font("Modern No. 20", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.Location = new System.Drawing.Point(885, 531);
            this.btnLogOut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(75, 25);
            this.btnLogOut.TabIndex = 9;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // dgvExpLvl
            // 
            this.dgvExpLvl.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvExpLvl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvExpLvl.Location = new System.Drawing.Point(324, 58);
            this.dgvExpLvl.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvExpLvl.Name = "dgvExpLvl";
            this.dgvExpLvl.RowHeadersWidth = 62;
            this.dgvExpLvl.RowTemplate.Height = 28;
            this.dgvExpLvl.Size = new System.Drawing.Size(570, 251);
            this.dgvExpLvl.TabIndex = 14;
            // 
            // btnComplete
            // 
            this.btnComplete.BackColor = System.Drawing.Color.OldLace;
            this.btnComplete.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComplete.Location = new System.Drawing.Point(505, 441);
            this.btnComplete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnComplete.Name = "btnComplete";
            this.btnComplete.Size = new System.Drawing.Size(183, 39);
            this.btnComplete.TabIndex = 41;
            this.btnComplete.Text = "Complete";
            this.btnComplete.UseVisualStyleBackColor = false;
            this.btnComplete.Click += new System.EventHandler(this.btnComplete_Click);
            // 
            // btnAddExpLvl
            // 
            this.btnAddExpLvl.BackColor = System.Drawing.Color.OldLace;
            this.btnAddExpLvl.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddExpLvl.Location = new System.Drawing.Point(52, 195);
            this.btnAddExpLvl.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddExpLvl.Name = "btnAddExpLvl";
            this.btnAddExpLvl.Size = new System.Drawing.Size(116, 45);
            this.btnAddExpLvl.TabIndex = 44;
            this.btnAddExpLvl.Text = "Add";
            this.btnAddExpLvl.UseVisualStyleBackColor = false;
            this.btnAddExpLvl.Click += new System.EventHandler(this.btnAddExpLvl_Click);
            // 
            // grpExperienceLvl
            // 
            this.grpExperienceLvl.Controls.Add(this.lblAddExpLvl);
            this.grpExperienceLvl.Controls.Add(this.btnAddExpLvl);
            this.grpExperienceLvl.Controls.Add(this.txtAddExpLvl);
            this.grpExperienceLvl.Controls.Add(this.cmbExpLvl);
            this.grpExperienceLvl.Controls.Add(this.lblExpLvl);
            this.grpExperienceLvl.Location = new System.Drawing.Point(45, 287);
            this.grpExperienceLvl.Name = "grpExperienceLvl";
            this.grpExperienceLvl.Size = new System.Drawing.Size(242, 256);
            this.grpExperienceLvl.TabIndex = 45;
            this.grpExperienceLvl.TabStop = false;
            this.grpExperienceLvl.Text = "Maintain Experience Level";
            // 
            // lblAddExpLvl
            // 
            this.lblAddExpLvl.AutoSize = true;
            this.lblAddExpLvl.Location = new System.Drawing.Point(16, 121);
            this.lblAddExpLvl.Name = "lblAddExpLvl";
            this.lblAddExpLvl.Size = new System.Drawing.Size(195, 17);
            this.lblAddExpLvl.TabIndex = 45;
            this.lblAddExpLvl.Text = "Add/Update Experience Level";
            // 
            // txtAddExpLvl
            // 
            this.txtAddExpLvl.Location = new System.Drawing.Point(19, 154);
            this.txtAddExpLvl.Name = "txtAddExpLvl";
            this.txtAddExpLvl.Size = new System.Drawing.Size(207, 22);
            this.txtAddExpLvl.TabIndex = 44;
            // 
            // cmbExpLvl
            // 
            this.cmbExpLvl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbExpLvl.FormattingEnabled = true;
            this.cmbExpLvl.Location = new System.Drawing.Point(19, 72);
            this.cmbExpLvl.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbExpLvl.Name = "cmbExpLvl";
            this.cmbExpLvl.Size = new System.Drawing.Size(184, 24);
            this.cmbExpLvl.TabIndex = 4;
            // 
            // lblExpLvl
            // 
            this.lblExpLvl.AutoSize = true;
            this.lblExpLvl.Location = new System.Drawing.Point(16, 33);
            this.lblExpLvl.Name = "lblExpLvl";
            this.lblExpLvl.Size = new System.Drawing.Size(116, 17);
            this.lblExpLvl.TabIndex = 5;
            this.lblExpLvl.Text = "Experience Level";
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(321, 336);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(269, 17);
            this.lblSearch.TabIndex = 46;
            this.lblSearch.Text = "Search according experience description:";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(629, 336);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(198, 22);
            this.txtSearch.TabIndex = 47;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // errTextbox
            // 
            this.errTextbox.ContainerControl = this;
            // 
            // errCombobox
            // 
            this.errCombobox.ContainerControl = this;
            // 
            // frmExperienceLevel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(972, 567);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.grpExperienceLvl);
            this.Controls.Add(this.btnComplete);
            this.Controls.Add(this.dgvExpLvl);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.grpExpLvl);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmExperienceLevel";
            this.Text = "Experience Level";
            this.Load += new System.EventHandler(this.frmExperienceLevel_Load);
            this.grpExpLvl.ResumeLayout(false);
            this.grpExpLvl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExpLvl)).EndInit();
            this.grpExperienceLvl.ResumeLayout(false);
            this.grpExperienceLvl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errTextbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errCombobox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpExpLvl;
        private System.Windows.Forms.RadioButton rdbDelete;
        private System.Windows.Forms.RadioButton rdbUpdate;
        private System.Windows.Forms.RadioButton rdbAdd;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.DataGridView dgvExpLvl;
        private System.Windows.Forms.Button btnComplete;
        private System.Windows.Forms.Button btnAddExpLvl;
        private System.Windows.Forms.GroupBox grpExperienceLvl;
        private System.Windows.Forms.Label lblAddExpLvl;
        private System.Windows.Forms.TextBox txtAddExpLvl;
        private System.Windows.Forms.Label lblExpLvl;
        private System.Windows.Forms.ComboBox cmbExpLvl;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.ErrorProvider errTextbox;
        private System.Windows.Forms.ErrorProvider errCombobox;
    }
}