﻿
namespace CMPG223_18
{
    partial class fmDanceTypes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fmDanceTypes));
            this.grpMaintainDT = new System.Windows.Forms.GroupBox();
            this.rdbDelete = new System.Windows.Forms.RadioButton();
            this.rdbUpdate = new System.Windows.Forms.RadioButton();
            this.rdbAdd = new System.Windows.Forms.RadioButton();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnAddDanceType = new System.Windows.Forms.Button();
            this.grpDanceTypes = new System.Windows.Forms.GroupBox();
            this.cmbDanceType = new System.Windows.Forms.ComboBox();
            this.lblDanceType = new System.Windows.Forms.Label();
            this.lblAddDanceType = new System.Windows.Forms.Label();
            this.txtAddDanceType = new System.Windows.Forms.TextBox();
            this.dgvDisplayDanceTypes = new System.Windows.Forms.DataGridView();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnComplete = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.errTextbox = new System.Windows.Forms.ErrorProvider(this.components);
            this.errCombobox = new System.Windows.Forms.ErrorProvider(this.components);
            this.grpMaintainDT.SuspendLayout();
            this.grpDanceTypes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDisplayDanceTypes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTextbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errCombobox)).BeginInit();
            this.SuspendLayout();
            // 
            // grpMaintainDT
            // 
            this.grpMaintainDT.BackColor = System.Drawing.Color.WhiteSmoke;
            this.grpMaintainDT.Controls.Add(this.rdbDelete);
            this.grpMaintainDT.Controls.Add(this.rdbUpdate);
            this.grpMaintainDT.Controls.Add(this.rdbAdd);
            this.grpMaintainDT.Location = new System.Drawing.Point(42, 52);
            this.grpMaintainDT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpMaintainDT.Name = "grpMaintainDT";
            this.grpMaintainDT.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpMaintainDT.Size = new System.Drawing.Size(248, 170);
            this.grpMaintainDT.TabIndex = 1;
            this.grpMaintainDT.TabStop = false;
            this.grpMaintainDT.Text = "Select Action";
            // 
            // rdbDelete
            // 
            this.rdbDelete.AutoSize = true;
            this.rdbDelete.Location = new System.Drawing.Point(19, 114);
            this.rdbDelete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbDelete.Name = "rdbDelete";
            this.rdbDelete.Size = new System.Drawing.Size(158, 21);
            this.rdbDelete.TabIndex = 2;
            this.rdbDelete.TabStop = true;
            this.rdbDelete.Text = "Delete Dance Types";
            this.rdbDelete.UseVisualStyleBackColor = true;
            this.rdbDelete.CheckedChanged += new System.EventHandler(this.rdbDelete_CheckedChanged);
            // 
            // rdbUpdate
            // 
            this.rdbUpdate.AutoSize = true;
            this.rdbUpdate.Location = new System.Drawing.Point(19, 79);
            this.rdbUpdate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbUpdate.Name = "rdbUpdate";
            this.rdbUpdate.Size = new System.Drawing.Size(163, 21);
            this.rdbUpdate.TabIndex = 1;
            this.rdbUpdate.TabStop = true;
            this.rdbUpdate.Text = "Update Dance Types";
            this.rdbUpdate.UseVisualStyleBackColor = true;
            this.rdbUpdate.CheckedChanged += new System.EventHandler(this.rdbUpdate_CheckedChanged);
            // 
            // rdbAdd
            // 
            this.rdbAdd.AutoSize = true;
            this.rdbAdd.Location = new System.Drawing.Point(19, 44);
            this.rdbAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbAdd.Name = "rdbAdd";
            this.rdbAdd.Size = new System.Drawing.Size(142, 21);
            this.rdbAdd.TabIndex = 0;
            this.rdbAdd.TabStop = true;
            this.rdbAdd.Text = "Add Dance Types";
            this.rdbAdd.UseVisualStyleBackColor = true;
            this.rdbAdd.CheckedChanged += new System.EventHandler(this.rdbAdd_CheckedChanged);
            // 
            // btnBack
            // 
            this.btnBack.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack.BackgroundImage")));
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBack.Location = new System.Drawing.Point(12, 11);
            this.btnBack.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(32, 29);
            this.btnBack.TabIndex = 5;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnAddDanceType
            // 
            this.btnAddDanceType.BackColor = System.Drawing.Color.OldLace;
            this.btnAddDanceType.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDanceType.Location = new System.Drawing.Point(45, 209);
            this.btnAddDanceType.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddDanceType.Name = "btnAddDanceType";
            this.btnAddDanceType.Size = new System.Drawing.Size(116, 45);
            this.btnAddDanceType.TabIndex = 47;
            this.btnAddDanceType.Text = "Add";
            this.btnAddDanceType.UseVisualStyleBackColor = false;
            this.btnAddDanceType.Click += new System.EventHandler(this.btnAddDanceType_Click);
            // 
            // grpDanceTypes
            // 
            this.grpDanceTypes.Controls.Add(this.cmbDanceType);
            this.grpDanceTypes.Controls.Add(this.lblDanceType);
            this.grpDanceTypes.Controls.Add(this.lblAddDanceType);
            this.grpDanceTypes.Controls.Add(this.txtAddDanceType);
            this.grpDanceTypes.Controls.Add(this.btnAddDanceType);
            this.grpDanceTypes.Location = new System.Drawing.Point(42, 243);
            this.grpDanceTypes.Name = "grpDanceTypes";
            this.grpDanceTypes.Size = new System.Drawing.Size(248, 274);
            this.grpDanceTypes.TabIndex = 48;
            this.grpDanceTypes.TabStop = false;
            this.grpDanceTypes.Text = "Maintain Dance Type";
            this.grpDanceTypes.Visible = false;
            // 
            // cmbDanceType
            // 
            this.cmbDanceType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDanceType.FormattingEnabled = true;
            this.cmbDanceType.Location = new System.Drawing.Point(21, 68);
            this.cmbDanceType.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbDanceType.Name = "cmbDanceType";
            this.cmbDanceType.Size = new System.Drawing.Size(184, 24);
            this.cmbDanceType.TabIndex = 52;
            // 
            // lblDanceType
            // 
            this.lblDanceType.AutoSize = true;
            this.lblDanceType.Location = new System.Drawing.Point(22, 38);
            this.lblDanceType.Name = "lblDanceType";
            this.lblDanceType.Size = new System.Drawing.Size(85, 17);
            this.lblDanceType.TabIndex = 51;
            this.lblDanceType.Text = "Dance Type";
            // 
            // lblAddDanceType
            // 
            this.lblAddDanceType.AutoSize = true;
            this.lblAddDanceType.Location = new System.Drawing.Point(12, 118);
            this.lblAddDanceType.Name = "lblAddDanceType";
            this.lblAddDanceType.Size = new System.Drawing.Size(164, 17);
            this.lblAddDanceType.TabIndex = 49;
            this.lblAddDanceType.Text = "Add/Update Dance Type";
            // 
            // txtAddDanceType
            // 
            this.txtAddDanceType.Location = new System.Drawing.Point(21, 147);
            this.txtAddDanceType.Name = "txtAddDanceType";
            this.txtAddDanceType.Size = new System.Drawing.Size(174, 22);
            this.txtAddDanceType.TabIndex = 48;
            // 
            // dgvDisplayDanceTypes
            // 
            this.dgvDisplayDanceTypes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDisplayDanceTypes.Location = new System.Drawing.Point(325, 89);
            this.dgvDisplayDanceTypes.Name = "dgvDisplayDanceTypes";
            this.dgvDisplayDanceTypes.RowHeadersWidth = 51;
            this.dgvDisplayDanceTypes.RowTemplate.Height = 24;
            this.dgvDisplayDanceTypes.Size = new System.Drawing.Size(588, 246);
            this.dgvDisplayDanceTypes.TabIndex = 49;
            this.dgvDisplayDanceTypes.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDisplayDanceTypes_CellContentDoubleClick);
            // 
            // btnLogOut
            // 
            this.btnLogOut.BackColor = System.Drawing.Color.OldLace;
            this.btnLogOut.Font = new System.Drawing.Font("Modern No. 20", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.Location = new System.Drawing.Point(869, 609);
            this.btnLogOut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(75, 25);
            this.btnLogOut.TabIndex = 50;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.UseVisualStyleBackColor = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnComplete
            // 
            this.btnComplete.BackColor = System.Drawing.Color.OldLace;
            this.btnComplete.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComplete.Location = new System.Drawing.Point(511, 478);
            this.btnComplete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnComplete.Name = "btnComplete";
            this.btnComplete.Size = new System.Drawing.Size(183, 39);
            this.btnComplete.TabIndex = 51;
            this.btnComplete.Text = "Complete";
            this.btnComplete.UseVisualStyleBackColor = false;
            this.btnComplete.Click += new System.EventHandler(this.btnComplete_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(630, 361);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(198, 22);
            this.txtSearch.TabIndex = 53;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(322, 361);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(269, 17);
            this.lblSearch.TabIndex = 52;
            this.lblSearch.Text = "Search according experience description:";
            // 
            // errTextbox
            // 
            this.errTextbox.ContainerControl = this;
            // 
            // errCombobox
            // 
            this.errCombobox.ContainerControl = this;
            // 
            // fmDanceTypes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 645);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.btnComplete);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.dgvDisplayDanceTypes);
            this.Controls.Add(this.grpDanceTypes);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.grpMaintainDT);
            this.Name = "fmDanceTypes";
            this.Text = "fmDanceTypes";
            this.Load += new System.EventHandler(this.fmDanceTypes_Load);
            this.grpMaintainDT.ResumeLayout(false);
            this.grpMaintainDT.PerformLayout();
            this.grpDanceTypes.ResumeLayout(false);
            this.grpDanceTypes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDisplayDanceTypes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errTextbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errCombobox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpMaintainDT;
        private System.Windows.Forms.RadioButton rdbDelete;
        private System.Windows.Forms.RadioButton rdbUpdate;
        private System.Windows.Forms.RadioButton rdbAdd;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnAddDanceType;
        private System.Windows.Forms.GroupBox grpDanceTypes;
        private System.Windows.Forms.ComboBox cmbDanceType;
        private System.Windows.Forms.Label lblDanceType;
        private System.Windows.Forms.Label lblAddDanceType;
        private System.Windows.Forms.TextBox txtAddDanceType;
        private System.Windows.Forms.DataGridView dgvDisplayDanceTypes;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button btnComplete;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.ErrorProvider errTextbox;
        private System.Windows.Forms.ErrorProvider errCombobox;
    }
}